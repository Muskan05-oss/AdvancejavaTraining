package modifideRectangle;

import java.util.Scanner;

public class ModifideRectangle {
	int length; 
    int breadth; 
    int area; 
    int parameter;
    
    public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return breadth;
	}

	public void setWidth(int width) {
		this.breadth = breadth;
	}

	
    public ModifideRectangle()
    {
    	length = 1;
    	breadth= 1;
    }

   public void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * breadth;
       
    }
 
     void  perimeterRectangle()
    {
    	 parameter = 2*(length + breadth);
       
    }

    void display() {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Parameter of Rectangle = " +parameter);}
       
        }

    public static void main(String args[]) {
    	
    	ModifideRectangle object = new ModifideRectangle();
        object.input();
        object.areaRectangle();
        object.perimeterRectangle();
        object.display();
        System.out.println(" ");
        ModifideRectangle object1 = new ModifideRectangle();
        object1.input();
        object1.areaRectangle();
        object1.perimeterRectangle();
        object1.display();
        System.out.println(" ");
        ModifideRectangle object2 = new ModifideRectangle();
        object2.input();
        object2.areaRectangle();
        object2.perimeterRectangle();
        object2.display();
        System.out.println(" ");
        ModifideRectangle object3 = new ModifideRectangle();
        object3.input();
        object3.areaRectangle();
        object3.perimeterRectangle();
        object3.display();
        System.out.println(" ");
        ModifideRectangle object4 = new ModifideRectangle();
        object4.input();
        object4.areaRectangle();
        object4.perimeterRectangle();
        object4.display();	
    }
}
