package number;

import java.util.Scanner;

public class Sum_Privious_one {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter first number");
		int x=s.nextInt();
		System.out.println("Enter second number");
		int y=s.nextInt();
		int count=0;
		System.out.print(x+" "+y);

		for(int i=0;i<13;i++) {
			count=x+y;
			System.out.print(" "+count);
			x=y;
			y=count;
			
		}
	}

}
