package rectangle;
 import java.util.Scanner;
 
 class Rectangle{
      int length; 
	  int breadth; 
	  int area; 

 
 public Rectangle()
 {
	length=0;
	breadth=0;
 }
 void input() {
     Scanner in = new Scanner(System.in);
     System.out.print("Enter length of rectangle: ");
     length = in.nextInt();
     System.out.print("Enter breadth of rectangle: ");
     breadth = in.nextInt();
 }

 void calculate() {
     area = length * breadth;
     
 }

 void display() {
     System.out.println("Area of Rectangle = " + area);
    
 }

 public static void main(String args[]) {
     Rectangle object1 = new Rectangle();
     object1.input();
     object1.calculate();
     object1.display();
     System.out.println("*********************************");
     Rectangle object2 = new Rectangle();
     object2.input();
     object2.calculate();
     object2.display();
     System.out.println("**********************************");
     Rectangle object3 = new Rectangle();
     object3.input();
     object3.calculate();
     object3.display();
     System.out.println("**********************************");
     Rectangle object4 = new Rectangle();
     object4.input();
     object4.calculate();
     object4.display();
     System.out.println("**********************************");
     Rectangle object5 = new Rectangle();
     object5.input();
     object5.calculate();
     object5.display();
 }
 }