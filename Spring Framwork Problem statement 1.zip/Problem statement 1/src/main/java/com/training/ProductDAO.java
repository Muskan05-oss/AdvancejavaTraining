package com.training;

public interface ProductDAO {
	
	public void insertProduct(String name,int price,int quantity,String catagory,String brand,String model);
	
	public void searchById(int id);
	
	public void deleteById(int id);
	
	public void updateById(int id,String name, int price,int quantity,String catagory, String brand, String model );
	public void displayAll();
	
	public void byCatagory(String catagory);
	
	public void byBrandOrModel(String brand, String model);
	
	public void byBrandAndModel(String brand, String model);
	
	public void byBrandOrModelOrCategory(String brand,String model, String category);

}
